import requests
import time
from resources.libs.common import logging
from resources.libs.common.config import CONFIG

def download_file_from_google_drive(id, destination, progress_dialog):
    URL = "https://drive.google.com/uc?export=download"

    session = requests.Session()

    response = session.get(URL, params = { 'id' : id, 'confirm': 'yTib' }, stream = True)
    token = get_confirm_token(response)

    if token:
        params = { 'id' : id, 'confirm' : token }
        response = session.get(URL, params = params, stream = True)
    

    if not response:
            logging.log_notify(CONFIG.ADDONTITLE, '[COLOR {0}]Build Install: Invalid Zip Url![/COLOR]'.format(CONFIG.COLOR2))
            return

    total = response.headers.get('content-length')
    save_response_content(response, destination, total, progress_dialog)    

def get_confirm_token(response):
    for key, value in response.cookies.items():
        if key.startswith('download_warning'):
            return value

    return None

def save_response_content(response, destination, total, progress_dialog):
    CHUNK_SIZE = 32768

    with open(destination, "wb") as f:
        if total is None:
            f.write(response.content)
            return
    
        downloaded = 0
        total = int(total)
        start_time = time.time()
        mb = 1024*1024

        for chunk in response.iter_content(CHUNK_SIZE):
            downloaded += len(chunk)
            f.write(chunk)
            done = int(100 * downloaded / total)
            kbps_speed = downloaded / (time.time() - start_time)
            
            if kbps_speed > 0 and not done >= 100:
                eta = (total - downloaded) / kbps_speed
            else:
                eta = 0
            
            kbps_speed = kbps_speed / 1024
            type_speed = 'KB'
            
            if kbps_speed >= 1024:
                kbps_speed = kbps_speed / 1024
                type_speed = 'MB'
                
            currently_downloaded = '[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]' % (CONFIG.COLOR2, CONFIG.COLOR1, downloaded / mb, CONFIG.COLOR1, total / mb)
            speed = '[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s ' % (CONFIG.COLOR2, CONFIG.COLOR1, kbps_speed, type_speed)
            div = divmod(eta, 60)
            speed += '[B]ETA:[/B] [COLOR %s]%02d:%02d[/COLOR][/COLOR]' % (CONFIG.COLOR1, div[0], div[1])
            progress_dialog.update(done, '\n' + str(currently_downloaded) + '\n' + str(speed))